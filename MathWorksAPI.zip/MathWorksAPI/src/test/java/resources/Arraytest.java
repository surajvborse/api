package resources;

public class Arraytest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
		int[] myarray1 = new int[10];
		myarray1[0] = 1;
		myarray1[1] = 12;
		myarray1[2] = 24;
		System.out.println(myarray1[0]);
		System.out.println(myarray1[1]);
		System.out.println(myarray1[2]);
*/
		int[] myarray = { 1, 3, 5, 7, 10, 11, 13, 17, 19, 23 };
		
		printmyArray(myarray);

	}

	public static void printmyArray(int[] array) {
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]);

		}
	}

}
