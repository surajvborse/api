package javapractice;

import java.util.Scanner;

public class Arraysdemo2 {

	public static void main(String[] args) {	
		
	int[] myNumbers = getNumbers(5);
	
	for(int i=0;i<myNumbers.length;i++) {
		System.out.println("Element " +i+ " values types was " + myNumbers[i]);
	}


	System.out.println("Average of numbers is " + getAverage(myNumbers));
	
	}
	
	private static Scanner scanner = new Scanner(System.in);
	
	public static int[] getNumbers(int no) {
		int[] values = new int[no];
		System.out.println("Enter "+no+ " interger values\r");
		for (int i=0;i<no;i++) {	
			
			values[i]=scanner.nextInt();	
		}
		
		return values;
		 
	}
	
	public static double getAverage(int[] numbers) {
		int sum=0;
		for(int i=0;i<numbers.length;i++) {
			sum +=numbers[i];
		}
		double average = (double) sum/numbers.length;
		return average;
		
		
	}
	
	
	
	
	

}
