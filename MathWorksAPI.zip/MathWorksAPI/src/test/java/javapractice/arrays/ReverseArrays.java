package javapractice.arrays;

public class ReverseArrays {

	public static void main(String[] args) {

		int[] myarray = { 1, 2, 3, 4, 5,6,7,8,9,10,11,12,13,14,15};
		//int[] myarray = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		
		int[] reversedArray=reversedArray(myarray);
		printArray(reversedArray);

	}
	
	public static int[] reversedArray(int[] myarray) {

		for (int i = 0; i < (myarray.length - 1) / 2; i++) {
			
			int tmp = myarray[i];

			myarray[i] = myarray[(myarray.length - 1) - i];
			myarray[(myarray.length-1) - i] = tmp;

		}
		
		return myarray;
	}
	
	public static void printArray(int[] array) {
		for(int i=0;i<array.length;i++) {
			System.out.println(array[i]);
		}
	}
	

}
