package javapractice.arrays;

public class MinimumNo {

	public static void main(String[] args) {
		
		int[] myArray = {56,32,6,6,3,78,90,-54,11,5,6,3,2,4,450,45,-23,3500};
	
		int min=myArray[0];
		int max=myArray[0];

		for(int i=1;i<myArray.length;i++) {
		
		if(min>myArray[i]) {
			
			min=myArray[i];
			
			}		
		
		
	if(max<myArray[i]) {
			
			max=myArray[i];
			
			}		
		}
		
		
	System.out.println(min);
	
	System.out.println(max);
}
	
	
	
	
}
