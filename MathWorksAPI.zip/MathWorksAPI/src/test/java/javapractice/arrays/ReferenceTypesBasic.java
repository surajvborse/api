package javapractice.arrays;

import java.util.Arrays;

public class ReferenceTypesBasic {

	public static void main(String[] args) {
		
		
		int myInt1 = 10;
		int myInt2 = myInt1;
		myInt1=15;
		
		System.out.println(myInt1);
		System.out.println(myInt2);
		
		int[] myArray1 = new int [5];
		
		//myArray1 = {1,2,3,4,5};
		
		int[] myArray2 = myArray1;
		
		myArray2[0]=15;
		
		System.out.println(Arrays.toString(myArray1));
		System.out.println(Arrays.toString(myArray2));
		
		

	}

}
