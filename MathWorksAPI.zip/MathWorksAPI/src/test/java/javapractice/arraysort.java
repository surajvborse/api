package javapractice;

import java.util.Scanner;

public class arraysort {

	public static void main(String[] args) {

		int[] myarray = getIntegers(7);
		
		int[] myarraycopy = myarray;
		
		sortArray(myarraycopy);
		
		printArray(myarraycopy);

	}

	private static Scanner scanner = new Scanner(System.in);

	public static int[] getIntegers(int no) {
		int[] values = new int[no];
		System.out.println("Enter " + no + " interger values\r");
		for (int i = 0; i < no; i++) {

			values[i] = scanner.nextInt();
		}

		return values;

	}

	public static int[] sortArray(int[] myarray) {
	for (int i = 0; i < myarray.length; i++) {
		for (int j = i + 1; j < myarray.length; j++) {
			int value = myarray[i];
			if (value < myarray[j]) {
				myarray[i] = myarray[j];
				myarray[j] = value;
			}
		}
	}
	return myarray;
}

	public static void printArray(int[] myarray) {
	for(int i = 0;i<myarray.length;i++)
	{
		System.out.println(myarray[i]);
	}
	}
}