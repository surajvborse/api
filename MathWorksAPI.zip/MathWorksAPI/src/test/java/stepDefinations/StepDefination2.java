package stepDefinations;

import static io.restassured.RestAssured.given;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;

import static org.junit.Assert.*;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.AddPlace;
import pojo.Location;
import resources.APIResources;
import resources.TestDataBuild;
import resources.Utils;

public class StepDefination2 extends Utils {

	RequestSpecification res;
	Response response;
// ResponseSpecification resspec;	
//-----Suggestions API response

	@Given("^API request details with the (.+)$")
	public void api_request_details_with_the_something(String searchterm) throws Throwable {

		res = given().baseUri("https://www.mathworks.com").queryParams("c[]", "hardware_catalog", "site_domain", "www",
				"site_language", "en", "term", "" + searchterm + "");

	}

	@When("^API is called with get method$")
	public void api_is_called_with_get_method() throws Throwable {
		response = res.when().get("searchresults/suggestions");

	}

	@Then("^API call should be success with status code (.+)$")
	public void api_call_should_be_success_with_status_code(int statuscode) throws Throwable {
		assertEquals(response.getStatusCode(), statuscode);
	}

	@And("^Response body should contain the (.+)$")
	public void response_body_should_contain_the(String searchterm) throws Throwable {
		Assert.assertTrue(response.asString().contains(searchterm));
		System.out.println("Suggestions response " + response.asString() + " contains the search term " + searchterm);

	}

//--------------Search API response

	@Given("^search API request with the (.+)$")
	public void search_api_request_with_the(String searchterm) throws Throwable {
		res = given().baseUri("https://www.mathworks.com").queryParams("fq[]", "hardware-support-vendor:adlink",
				// "fq[1]","subcollection:(hardware_catalog)",
				"page", "1", "rows", "25", "facet.limit", "200", "c[]", "hardware_catalog", "facet.mincount", "0",
				"facets",
				"product_base_code,product-family,hardware-support-vendor,marketing-application,hardware-support-protocol-standard",
				"sort",
				"query({!v=\"asset_language:([en TO en]^2 OR [en TO en]^1)\"})desc,score desc,title_sort_en asc",
				"site_domain", "www", "site_language", "en", "fl",
				"asset_id, subcollection, asset_type, asset_type_name, id, asset_language, url, updated_at, thumbnail, title_*, primary_header_*, meta_description_*, body_*, hardware-support-vendor, hardware-support-custom-tags, support-package-installer-enabled",
				"q", "" + searchterm + "");
	}

	@When("^search API is called with get method$")
	public void search_api_is_called_with_get_method() throws Throwable {
		response = res.when().get("/searchresults/results");
	}

	@Then("^search API call should be success with status code 200$")
	public void search_api_call_should_be_success_with_status_code_200() throws Throwable {
		assertEquals(response.getStatusCode(), 200);
	}

	@And("^First search results title should be displayed as (.+)$")
	public void first_search_results_title_should_be_displayed_as(String expectedTitle) throws Throwable {
		JsonPath js = new JsonPath(response.asString());
		String firstTitle = js.getString("response.docs.title_en");
		assertEquals(firstTitle, expectedTitle);
		System.out.println("First title in response " + firstTitle + " is equal to expected title " + expectedTitle);
	}

}

/*
 * @Given("^API request details with the search term$") public void
 * api_request_details_with_the_search_term() throws Throwable {
 * 
 * res = given().baseUri("https://www.mathworks.com").queryParams("c[]",
 * "hardware_catalog", "site_domain", "www", "site_language", "en", "term",
 * "camera");
 * 
 * }
 */

/*
 * @Then("^API call should be success with status code 200$") public void
 * api_call_should_be_success_with_status_code_200() throws Throwable {
 * 
 * assertEquals(response.getStatusCode(), 200);
 * 
 * }
 */

/*
 * @And("^Response body should contain the search term$") public void
 * response_body_should_contain_the_search_term() throws Throwable {
 * System.out.println(response.asString());
 * Assert.assertTrue(response.asString().contains("camera"));
 * System.out.println("Test success"); // String actualvalue
 * =getJsonPath1(response,"0"); // System.out.println(actualvalue); }
 */

/*
 * @Given("^search API request with the searchTerm$") public void
 * search_api_request_with_the_searchterm() throws Throwable {
 * 
 * res = given().baseUri("https://www.mathworks.com").queryParams("fq[]",
 * "hardware-support-vendor:adlink", //
 * "fq[1]","subcollection:(hardware_catalog)", "page", "1", "rows", "25",
 * "facet.limit", "200", "c[]", "hardware_catalog", "facet.mincount", "0",
 * "facets",
 * "product_base_code,product-family,hardware-support-vendor,marketing-application,hardware-support-protocol-standard",
 * "sort",
 * "query({!v=\"asset_language:([en TO en]^2 OR [en TO en]^1)\"})desc,score desc,title_sort_en asc"
 * , "site_domain", "www", "site_language", "en", "fl",
 * "asset_id, subcollection, asset_type, asset_type_name, id, asset_language, url, updated_at, thumbnail, title_*, primary_header_*, meta_description_*, body_*, hardware-support-vendor, hardware-support-custom-tags, support-package-installer-enabled"
 * , "q", "camera"); }
 */